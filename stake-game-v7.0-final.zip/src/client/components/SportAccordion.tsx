import { useState } from 'react'
import { ChevronDown, Clock } from 'lucide-react'
import { format } from 'date-fns'
import { ptBR } from 'date-fns/locale'
import { toast } from 'sonner'
import TeamLogo from './TeamLogo'

interface Outcome {
  name: string
  price: number
}

interface Match {
  id: string
  home_team: string
  away_team: string
  commence_time: string
  outcomes: Outcome[]
}

interface Props {
  league: string
  matches: Match[]
  onBet: (match: Match, outcome: Outcome) => void
}

export default function SportAccordion({ league, matches, onBet }: Props) {
  const [isOpen, setIsOpen] = useState(false)

  // Ensure matches is always an array
  const safeMatches = Array.isArray(matches) ? matches : []
  // Ensure league is a string
  const leagueName = typeof league === 'string' ? league : 'Campeonato'

  const handleBetClick = (match: Match, selectionName: string, odds: number) => {
      if(!localStorage.getItem('token')) {
          toast.error('Faça login para apostar')
          return
      }
      onBet(match, { name: selectionName, price: odds })
  }

  const formatDate = (dateStr: string) => {
      try {
          const date = new Date(dateStr)
          const today = new Date()
          const isToday = date.getDate() === today.getDate() && date.getMonth() === today.getMonth()
          const time = format(date, 'HH:mm')
          const day = format(date, 'dd/MM', { locale: ptBR })
          return isToday ? `Hoje ${time}` : `${day} ${time}`
      } catch (e) {
          return ''
      }
  }

  if (safeMatches.length === 0) return null

  return (
    <div className="mb-2 bg-surface rounded-lg overflow-hidden border border-white/5 shadow-sm">
      {/* Header - More Compact */}
      <button 
        onClick={() => setIsOpen(!isOpen)}
        className="w-full flex items-center justify-between px-4 py-3 bg-[#1a2c38] hover:bg-[#233542] transition-colors"
      >
        <div className="flex items-center gap-2">
            <div className="w-6 h-6 rounded-full bg-white/5 flex items-center justify-center text-primary font-bold text-[10px]">
                {leagueName.substring(0, 2).toUpperCase()}
            </div>
            <span className="font-bold text-white text-xs uppercase tracking-wide text-left">{leagueName.replace('Brazil - ', '')}</span>
        </div>
        <ChevronDown 
            size={16} 
            className={`text-gray-400 transition-transform duration-300 ${isOpen ? 'rotate-180' : ''}`} 
        />
      </button>

      {/* Matches */}
      <div className={`transition-all duration-300 ease-in-out ${isOpen ? 'max-h-[2000px] opacity-100' : 'max-h-0 opacity-0'}`}>
        <div className="divide-y divide-gray-800">
            {safeMatches.map(match => {
                const outcomes = match.outcomes || []
                
                const homeOutcome = outcomes.find(o => o.name === match.home_team)
                const drawOutcome = outcomes.find(o => o.name === 'Draw')
                const awayOutcome = outcomes.find(o => o.name === match.away_team)

                const homeOdds = homeOutcome?.price || 1.00
                const drawOdds = drawOutcome?.price || 1.00
                const awayOdds = awayOutcome?.price || 1.00

                return (
                    <div key={match.id} className="px-4 py-3 hover:bg-white/5 transition-colors">
                        <div className="flex flex-col md:flex-row gap-3 justify-between items-center">
                            
                            <div className="flex-1 w-full">
                                <div className="flex items-center gap-2 text-[10px] text-textMuted mb-2">
                                    <Clock size={10} />
                                    <span>{formatDate(match.commence_time)}</span>
                                </div>
                                
                                <div className="space-y-1.5">
                                    <div className="flex items-center justify-between">
                                        <div className="flex items-center gap-2">
                                            <TeamLogo name={match.home_team} size={16} />
                                            <span className="font-bold text-white text-xs">{match.home_team}</span>
                                        </div>
                                    </div>
                                    <div className="flex items-center justify-between">
                                        <div className="flex items-center gap-2">
                                            <TeamLogo name={match.away_team} size={16} />
                                            <span className="font-bold text-white text-xs">{match.away_team}</span>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div className="flex gap-1.5 w-full md:w-auto mt-2 md:mt-0">
                                <BetButton label="1" odds={homeOdds} onClick={() => handleBetClick(match, match.home_team, homeOdds)} />
                                <BetButton label="X" odds={drawOdds} onClick={() => handleBetClick(match, 'Draw', drawOdds)} />
                                <BetButton label="2" odds={awayOdds} onClick={() => handleBetClick(match, match.away_team, awayOdds)} />
                            </div>
                        </div>
                    </div>
                )
            })}
        </div>
      </div>
    </div>
  )
}

function BetButton({ label, odds, onClick }: { label: string, odds: number, onClick: () => void }) {
    return (
        <button 
            onClick={onClick}
            className="flex-1 md:w-20 bg-[#213743] hover:bg-[#2b4250] active:scale-95 transition-all p-1.5 rounded-md flex flex-col items-center justify-center border border-transparent hover:border-gray-600 group shadow-[inset_0_2px_4px_rgba(0,0,0,0.3)] hover:shadow-[inset_0_2px_4px_rgba(0,0,0,0.5)]"
        >
            <span className="text-[10px] text-textMuted group-hover:text-gray-300 font-medium mb-0.5">{label}</span>
            <span className="text-[#00E701] font-bold text-xs tracking-wide drop-shadow-sm">{odds.toFixed(2)}</span>
        </button>
    )
}
